function [L_msd] = msdlosses(h_BS, h_roof, f_c, d, b, City)
%%                      DESCRIPTION                         %%
%A function calculating the multiscreen diffraction losses.
%The input parameters are:
%f_c: frequency (MHz)
%h_MS: heigth of the Mobile Station (m)
%h_roof: heigth of roof in which the BS is located (m)
%d: distance between the 2 stations (km)
%City: Binary flag. True (1) is for a small city, False (0) is for a
%      Metropolis
%b: building distance (m)
    Dh_base = h_BS - h_roof;
    if(Dh_base > 0)
      L_bsh = -18*log(1 + (Dh_base));
      k_a = 54;
      k_d = 18;
    else
      L_bsh = 0;
      if(d >= 0.5)
          k_a = 54 - 0.8*(Dh_base);
      else
          k_a = 54 - 0.8*(Dh_base)*(d/0.5);
      end
      k_d = 18 - (Dh_base/h_roof);
    end
    if(City == true)
        k_f = 4 - 0.7*((f_c/925) - 1);
    else
        k_f = 4 - 1.8*((f_c/925) - 1);
    end
    L_msd = L_bsh + k_a + k_d*log(d) + k_f*log(f_c) - 9*log(b);
    
end
