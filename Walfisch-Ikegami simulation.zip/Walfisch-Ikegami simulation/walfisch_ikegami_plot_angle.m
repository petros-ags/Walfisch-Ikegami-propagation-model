function [A_LdB, A_L] = walfisch_ikegami_plot_angle()
%Scenario - NLOS Losses by increasing the angle parameter from 0
%degrees to 90 degrees. The frequency (f), base station heigth
%(h_BS),the distance between the buildings (b) and the height of
%the roof of the buildings all take different values.
%Fixed parameters are the distance between the Mobile and the Base station
%and the Height of the Mobile station.
%OUTPUTS: The output of this function are the Losses of the simulations
%         both in dB and Watts.

    check_bounds = @(A,x,y)all((bitand((A >= x*ones(size(A))), (A <= y*ones(size(A))))));
    
    h_MS = 2;%m: 1-3
    d = 3;%km: 0.02-5
    h_roof_metro = 21;%m
    h_roof_small = 9;%m
    h_roofs = [h_roof_metro, h_roof_small];
    h_BS = h_roofs + 3; %for Base stations above the other buildings in Metrpolitan and Suburban areas.
    LOS = true;%line of sight->true || No-LOS->false
    City = true;%big city
    fc = [960 1550 1950];
    b = [23.5 37.5 48.7];
    if(check_bounds(fc,800,2000) && (d >= 0.02)&&(d <= 5) && check_bounds(h_BS,4,50) && (h_MS >= 1)&&(h_MS <= 3))
        angle = [0:5:90];
        A_LdB = zeros(length(fc)*length(b), length(angle), 2);
        A_L = A_LdB;
        for x = [1,2]
            for i = [1:length(angle)]
                for j = [1:length(fc)]
                    for k = [1:length(b)]
                        [A_LdB((j-1)*length(fc)+k,i,x),A_L((j-1)*length(fc)+k,i,x)] = WalfichIkegami(fc(j), h_BS(x), h_MS, d, ~LOS, h_roofs(x), b(k), City, angle(i));
                    end
                end    
            end
            City = ~City;
        end
        
        %Plot for Metropolis model
        figure('Name', 'Angle Losses for a Metropolis scenario');
        AxesH = axes('Ylim', [310, 360], 'YTick', 310:2.5:360, 'NextPlot', 'add');
        grid on;
        plot(angle, A_LdB(7,:,1), '-+b', angle, A_LdB(4,:,1), '-sb', angle, A_LdB(8,:,1), '-+r',...
             angle, A_LdB(9,:,1), '-+g', angle, A_LdB(5,:,1), '-sr', angle, A_LdB(1,:,1), '-db',...
             angle, A_LdB(6,:,1), '-sg', angle, A_LdB(2,:,1), '-dr', angle, A_LdB(3,:,1), '-dg');
        legend(sprintf('f=%dMHz,b=%.1fm', fc(3), b(1)),sprintf('f=%dMHz,b=%.1fm', fc(2), b(1)),sprintf('f=%dMHz,b=%.1fm', fc(3), b(2)),...
               sprintf('f=%dMHz,b=%.1fm', fc(3), b(3)),sprintf('f=%dMHz,b=%.1fm', fc(2), b(2)),sprintf('f=%dMHz,b=%.1fm', fc(1), b(1)),...
               sprintf('f=%dMHz,b=%.1fm', fc(2), b(3)),sprintf('f=%dMHz,b=%.1fm', fc(1), b(2)),sprintf('f=%dMHz,b=%.1fm', fc(1), b(3)), 'Location', 'southeastoutside');
        xlabel('Angle [\circ]');
        ylabel('Losses [dB]');
        fixed_param = sprintf('Fixed Parameters: H_{BS}=%.1fm, H_{MS}=%.1fm, H_{roof}=%.1fm, d=%.1fm',h_BS(1),h_MS,h_roofs(1),d);
        title({'Losses vs Angle | Metropolis',fixed_param});
        %Plot for Small city model
        figure('Name', 'Angle Losses for a Small scenario');
        AxesH = axes('Ylim', [290, 330], 'YTick', 290:2.5:330, 'NextPlot', 'add');
        grid on;
        plot(angle, A_LdB(7,:,2), '-+b', angle, A_LdB(4,:,2), '-sb', angle, A_LdB(8,:,2), '-+r',...
             angle, A_LdB(1,:,2), '-db', angle, A_LdB(5,:,2), '-sr', angle, A_LdB(9,:,2), '-+g',...
             angle, A_LdB(6,:,2), '-sg', angle, A_LdB(2,:,2), '-dr', angle, A_LdB(3,:,2), '-dg'); 
        legend(sprintf('f=%dMHz,b=%.1fm', fc(3), b(1)), sprintf('f=%dMHz,b=%.1fm', fc(2), b(1)), sprintf('f=%dMHz,b=%.1fm', fc(3), b(2)),...
               sprintf('f=%dMHz,b=%.1fm', fc(1), b(1)), sprintf('f=%dMHz,b=%.1fm', fc(2), b(2)), sprintf('f=%dMHz,b=%.1fm', fc(3), b(3)),...
               sprintf('f=%dMHz,b=%.1fm', fc(2), b(3)), sprintf('f=%dMHz,b=%.1fm', fc(1), b(2)), sprintf('f=%dMHz,b=%.1fm', fc(1), b(3)), 'Location', 'southeastoutside');
        xlabel('Angle [\circ]');
        ylabel('Losses [dB]');
        fixed_param = sprintf('Fixed Parameters: H_{BS}=%.1fm, H_{MS}=%.1fm, H_{roof}=%.1fm, d=%.1fm',h_BS(2),h_MS,h_roofs(2),d);
        title({'Losses vs Angle | Small city',fixed_param});
    else
        figure;
        plot(1000,1000);
    end
    
end