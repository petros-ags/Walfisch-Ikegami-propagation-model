function [F_LdB, F_L] = walfisch_ikegami_plot_freq()
%This function simulates the Losses gained when changing the distance
%between the base station and mobile station and the frequency used to
%transmit data between them. Fixed parameters:
%Distance between buildings b: 35m, [20,50] m
%angle: 90�, [0,90] �
%Height of mobile station: 2m, [1,3] m
%Height of a roof in a metropolitan scenario h_roof_metro: 21m
%Height of a roof in a small city scenario h_roof_metro: 9m
%Height of the Base station is calculated according to the height of the
%   roof of the scenario with the assumption that we have a flat roof:
%   h_BS = roof_height + 3 m
%OUTPUTS: The output of this function are the Losses of the simulations
%         both in dB and Watts.



 
    check_bounds = @(A,x,y)all((bitand((A >= x*ones(size(A))), (A <= y*ones(size(A))))));
    f_c = 1400;%MHz: 800-2000
    %h_BS = 25;%m: 4-50
    h_MS = 2;%m: 1-3
    d = 2.51;%km: 0.02-5
    angle= 90;%degrees: 0-90
    b = 35;%m: 20-50
    
    h_roof_metro = 21;
    h_roof_small = 9; 
    h_roofs = [h_roof_metro, h_roof_small];
    h_BS = h_roofs + 3; %for Base stations above the other buildings in Metrpolitan and Suburban areas.
    LOS = true;%line of sight->true || No-LOS->false
    City = true;%big city


    if((800 <= f_c)&&(f_c <= 2000) && (d >= 0.02)&&(d <= 5) && check_bounds(h_BS,4,50) && (h_MS >= 1)&&(h_MS <= 3))
        fc2 = [800:50:2000];
        d2 = [0.1, 2.5, 4];
        rows = length(d2) + length(d2)*2;
        F_LdB = zeros(rows,length(fc2));
        F_L = F_LdB;
        for i=1:length(fc2)
            for j = 1:rows
                if (j < 4)   %LOS model
                    [F_LdB(j,i), F_L(j,i)] = WalfichIkegami(fc2(i), h_BS(1), h_MS, d2(j), LOS, h_roofs(1), b, City, angle);
                elseif (j >=4 && j <7)   %NLOS model. Taking in account the Metropolitan cities
                    [F_LdB(j,i), F_L(j,i)] = WalfichIkegami(fc2(i), h_BS(1), h_MS, d2(j-3), ~LOS, h_roofs(1), b, City, angle);
                else    %NLOS model. Taking in account the Metropolitan cities
                    [F_LdB(j,i), F_L(j,i)] = WalfichIkegami(fc2(i), h_BS(1), h_MS, d2(j-6), ~LOS, h_roofs(2), b, ~City, angle);                   
                end
            end
        end    
        figure('Name','Losses over increasing Frequency');
        %D1->*  ||  D2->x   ||  D3->+
        AxesH = axes('Ylim', [100, 400], 'YTick', 100:25:400, 'NextPlot', 'add');
        plot(fc2,F_LdB(6,:),'-+r',fc2,F_LdB(5,:),'-xr',... 
             fc2,F_LdB(9,:),'-+g',fc2,F_LdB(8,:),'-xg',...  
             fc2,F_LdB(3,:),'-+b',fc2,F_LdB(2,:),'-xb',...
             fc2,F_LdB(4,:),'-*r',fc2,F_LdB(7,:),'-*g',fc2,F_LdB(1,:),'-*b');   
        title_str = sprintf('Fixed parameters: H_{BS Metro}=%dm, H_{BS Small}=%.1fm, H_{MS}=%.1fm, Metropolis H_{roof}=%.1fm, Small City H_{roof}=%.1fm,\\phi=%.1f\\circ, b=%.1fm',...
           h_BS(1), h_BS(2), h_MS,h_roof_metro, h_roof_small, angle, b);
        title({'Losses vs Frequency',title_str});
        xlabel('Frequency [MHz]');
        ylabel('Losses [dB]');
        grid on;
        legend('d_{3}=4m,NLOS,Metro','d_{2}=2.5m,NLOS,Metro',...
               'd_{3}=4m,NLOS,Small','d_{2}=2.5m,NLOS,Small',...
               'd_{3}=4m,LOS,N/A','d_{2}=2.5m,LOS,N/A',...
               'd_{1}=0.1m,NLOS,Metro','d_{1}=0.1m,NLOS,Small','d_{1}=0.1m,LOS,N/A',...
               'Location','southeastoutside','Orientation','vertical');
    else
        figure;
        plot(1000,1000);
    end

end

