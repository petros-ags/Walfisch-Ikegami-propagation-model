%%Main program that calls all the simulation functions.
close all;
%Losses due to the variation of distance
[D_LdB, D_L] = walfisch_ikegami_plot_distance();
%Losses due to the variation of frequency
[F_LdB, F_L] = walfisch_ikegami_plot_freq();
%Losses due to the variation of the Height of the base station
[HBS_LdB, HBS_L] = walfisch_ikegami_plot_hbs();
%Losses due to the variation of the angle
[A_LdB, A_L] = walfisch_ikegami_plot_angle();
%Losses due to the variation of the distance between the buildings
[B_LdB,B_L] = walfisch_ikegami_plot_b();
%Final plot summarizing the model
walfisch_ikegami_final_plot();