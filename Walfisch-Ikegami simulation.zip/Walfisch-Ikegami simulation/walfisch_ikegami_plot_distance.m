function [D_LdB, D_L] = walfisch_ikegami_plot_distance()
%This function simulates the Losses gained when changing the distance
%between the base station and mobile station and the frequency used to
%transmit data between them. Fixed parameters:
%Distance between buildings b: 35m, [20,50] m
%angle: 90�, [0,90] �
%Height of mobile station: 2m, [1,3] m
%Height of a roof in a metropolitan scenario h_roof_metro: 21m
%Height of a roof in a small city scenario h_roof_metro: 9m
%Height of the Base station is calculated according to the height of the
%   roof of the scenario with the assumption that we have a flat roof:
%   h_BS = roof_height + 3 m
%OUTPUTS: The output of this function are the Losses of the simulations
%         both in dB and Watts.



 
    check_bounds = @(A,x,y)all((bitand((A >= x*ones(size(A))), (A <= y*ones(size(A))))));
    f_c = 1400;%MHz: 800-2000
    %h_BS = 25;%m: 4-50
    h_MS = 2;%m: 1-3
    d = 2.51;%km: 0.02-5
    angle= 90;%degrees: 0-90
    b = 35;%m: 20-50
    
    h_roof_metro = 21;
    h_roof_small = 9; 
    h_roofs = [h_roof_metro, h_roof_small];
    h_BS = h_roofs + 3; %for Base stations above the other buildings in Metrpolitan and Suburban areas.
    LOS = true;%line of sight->true || No-LOS->false
    City = true;%big city


    if((800 <= f_c)&&(f_c <= 2000) && (d >= 0.02)&&(d <= 5) && check_bounds(h_BS,4,50) && (h_MS >= 1)&&(h_MS <= 3))
        %Scenario 1 - LOS - x: d and f_c takes various "fixed" values  
        d1 = [0.02:0.25:5];
        fc1 = [850 1400 1900];
        rows=length(fc1) + length(fc1)*2;
        D_LdB = zeros(rows,length(d1));
        D_L = D_LdB;
        for i=1:length(d1)
            for j = 1:rows
                if (j < 4)   %LOS model
                    [D_LdB(j,i), D_L(j,i)] = WalfichIkegami(fc1(j), h_BS(1), h_MS, d1(i), LOS, h_roofs(1), b, City, angle);
                elseif (j >=4 && j <7)   %NLOS model. Taking in account the Metropolitan cities
                    [D_LdB(j,i), D_L(j,i)] = WalfichIkegami(fc1(j-3), h_BS(1), h_MS, d1(i), ~LOS, h_roofs(1), b, City, angle);
                else    %NLOS model. Taking in account the Metropolitan cities
                    [D_LdB(j,i), D_L(j,i)] = WalfichIkegami(fc1(j-6), h_BS(2), h_MS, d1(i), ~LOS, h_roofs(2), b, ~City, angle);                   
                end
            end
        end    

        figure('Name','Losses over increasing Distance');
        %F1->*  ||  F2->x   ||  F3->+
        AxesH = axes('Ylim', [50, 400], 'YTick', 50:12.5:400, 'NextPlot', 'add');
        plot(d1,D_LdB(6,:),'-+r',d1,D_LdB(5,:),'-xr',d1,D_LdB(4,:),'-*r',... %plotting the NLOS frequencies for a Metropolis
             d1,D_LdB(9,:),'-+g',d1,D_LdB(8,:),'-xg',d1,D_LdB(7,:),'-*g',...  %plotting the NLOS frequencies for a Small city
             d1,D_LdB(3,:),'-+b',d1,D_LdB(2,:),'-xb',d1,D_LdB(1,:),'-*b');   %plotting the LOS frequencies
        title_str = sprintf('Fixed parameters: H_{BS Metro}=%dm, H_{BS Small}=%dm, H_{MS}=%dm, Metropolis H_{roof}=%dm, Small City H_{roof}=%dm,\\phi=%d\\circ, b=%dm',...
            h_BS(1), h_BS(2), h_MS,h_roof_metro, h_roof_small, angle, b);
        title({'Losses vs Distance',title_str});
        xlabel('Distance [km]');
        ylabel('Losses [dB]');
        grid on;
        legend('f_{3}=1900MHz,NLOS,Metro','f_{2}=1400MHz,NLOS,Metro','f_{1}=850MHz,NLOS,Metro',...
               'f_{3}=1900MHz,NLOS,Small','f_{2}=1400MHz,NLOS,Small','f_{1}=850MHz,NLOS,Small',...
               'f_{3}=1900MHz,LOS,N/A','f_{2}=1400MHz,LOS,N/A','f_{1}=850MHz,LOS,N/A','Location','southeastoutside','Orientation','vertical');
    else
        figure;
        plot(1000,1000);
    end

  end