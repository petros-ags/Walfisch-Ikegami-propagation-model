function [B_LdB,B_L] = walfisch_ikegami_plot_b()
%This function calculates the propagation losses when the distance between
%the buildings is variating linearly. The simulation regards a metropolitan
%area and a small city.
%Fixed parameters:
%angle: 90�, [0,90] �
%Height of mobile station: 2m, [1,3] m
%Height of a roof in a metropolitan scenario h_roof_metro: 21m
%Height of a roof in a small city scenario h_roof_metro: 9m
%Height of the Base station is calculated according to the height of the
%   roof of the scenario with the assumption that we have a flat roof:
%   h_BS = roof_height + 3 m
%OUTPUTS: The output of this function are the Losses of the simulations
%         both in dB and Watts.

    h_MS = 2;%m: 1-3
    h_roof_metro = 21;%m
    h_roof_small = 9;%m
    h_roofs = [h_roof_metro, h_roof_small];
    h_BS = h_roofs + 3; %for Base stations above the other buildings in Metrpolitan and Suburban areas.
    LOS = true;%line of sight->true || No-LOS->false
    City = true;%big city
    fc = [1200 1770];%MHz
    d = [1.5 3.755];%m
    angle = 90;%degrees
    b = [20:1.5:50];%m
    rows = length(fc)*length(d);
    B_LdB = zeros(rows, length(b),2);
    B_L = B_LdB;
    for x = [1,2]
        for i = [1:length(b)]
            for j = [1:length(fc)]
                for k = [1:length(d)]
                    [B_LdB((j-1)*length(fc)+k,i,x), B_L((j-1)*length(fc)+k,i,x)] = WalfichIkegami(fc(j), h_BS(x), h_MS, d(k), ~LOS, h_roofs(x), b(i), City, angle);
                end
            end
        end
        City = ~City;
    end
    figure('Name','Losses for different building distance | Metropolis');
    AxesH = axes('Ylim', [290, 370], 'YTick', 290:5:370, 'NextPlot', 'add');
    plot(b,B_LdB(4,:,1), '-*g',b,B_LdB(2,:,1), '-+g',b,B_LdB(3,:,1), '-*r',b,B_LdB(1,:,1), '-+r');
    grid on;
    legend(sprintf('f=%dMHz,d=%.1fm', fc(2), d(2)),sprintf('f=%dMHz,d=%.1fm', fc(1), d(2)),...
           sprintf('f=%dMHz,d=%.1fm', fc(2), d(1)),sprintf('f=%dMHz,d=%.1fm', fc(1), d(1)), 'Location', 'southeastoutside');
    fixed_params = sprintf('Fixed Parameters:H_{BS}=%.1fm, H_{MS}=%.1fm, H_{roof}=%.1fm, \\phi=%d\\circ',h_BS(1),h_MS,h_roofs(1),angle);
    title({'Losses vs distance between building | Metropolis',fixed_params});
    xlabel('Building distance[m]');
    ylabel('Losses [dB]');
    figure('Name','Losses for different building distance | Small city');
    AxesH = axes('Ylim', [270, 340], 'YTick', 270:5:340, 'NextPlot', 'add');
    grid on;
    plot(b,B_LdB(4,:,2), '-*g',b,B_LdB(2,:,2), '-+g',b,B_LdB(3,:,2), '-*r',b,B_LdB(1,:,2), '-+r');
    legend(sprintf('f=%dMHz,d=%.1fm', fc(2), d(2)),sprintf('f=%dMHz,d=%.1fm', fc(1), d(2)),...
           sprintf('f=%dMHz,d=%.1fm', fc(2), d(1)),sprintf('f=%dMHz,d=%.1fm', fc(1), d(1)), 'Location', 'southeastoutside');
    fixed_params = sprintf('Fixed Parameters:H_{BS}=%.1fm, H_{MS}=%.1fm, H_{roof}=%.1fm, \\phi=%d\\circ',h_BS(2),h_MS,h_roofs(2),angle);
    title({'Losses vs distance between building | Small city',fixed_params});
    xlabel('Building distance[m]');
    ylabel('Losses [dB]');
    
end

