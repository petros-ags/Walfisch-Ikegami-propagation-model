function walfisch_ikegami_final_plot()
%A function that sums up the overall loses from the previous simulations.
%Specificaly, the losses regarding the variations in the angle, the height
%of the base station in both metropolis and small city scenarios, the
%distance and the frequency.
%Losses in regards to the variance rate:
%Frequency: increasing 
%Base station heigth:decreasing
%b: decreasing
%Angle is set to the worst case scenario due to discontinuity
    fc = linspace(800,2000,5);
    b = linspace(50,20,5);
    h_BS = linspace(50,21,5);
    h_MS = 2;%m
    d = [0.02:0.25:5];
    h_roof_metro = 21;%m
    angle = 90;%degrees
    LOS = false;
    City = true;%Metropolis->true || Small city->false
    LdB = zeros(5,length(d),2);
    L = LdB;
    for x = [1 2]
        for i = [1:length(d)]
            for j = [1:length(fc)]
                [LdB(j,i,x), L(j,i,x)] = WalfichIkegami(fc(j), h_BS(j), h_MS, d(i), LOS, h_roof_metro, b(j), City, angle);
            end
        end
        LOS = ~LOS;
    end
    figure('Name', 'Summarization results');
    plot(d,LdB(5,:,1),'-o',d,LdB(4,:,1),'-+',d,LdB(3,:,1),'-*',d,LdB(2,:,1),'-.',d,LdB(1,:,1),'-x',...
         d,LdB(5,:,2),'-s',d,LdB(4,:,2),'-d',d,LdB(3,:,2),'-^',d,LdB(2,:,2),'-v',d,LdB(1,:,2),'->');
    grid on;
    ylabel('Losses [dB]');
    xlabel('Distance [m]');
    fixed_params = sprintf("Fixed parameters: H_{MS}=%.1fm, H_{roof}=%.1fm,\\phi=%d\\circ", h_MS,h_roof_metro,angle);
    title({'Summarized results',fixed_params});
    legends = strings(1,2*length(fc));
    for i = [1:2*length(fc)]
        if i <= 5
            legends(i) = sprintf("f=%.2fMHz,H_{BS}=%.2fm, b=%.2fm, LOS",fc(length(fc)-i+1),h_BS(length(fc)-i+1),b(length(fc)-i+1));
        else
            legends(i) = sprintf("f=%.2fMHz,H_{BS}=%.2fm, b=%.2fm, NLOS",fc(2*length(fc)-i+1),h_BS(2*length(fc)-i+1),b(2*length(fc)-i+1));            
        end
    end
    legend(legends,'Location', 'southeastoutside');
end

