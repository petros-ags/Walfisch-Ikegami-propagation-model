function [L_rts] = rtslosses(angle, w, h_roof, h_MS, f_c)
%%                          DESCRIPTION                            %%
%A function that calculates the rooftop to street difraction losses.
%The input parameters are:
%angle: in degrees. The angle between incidences coming from base 
%       station and road
%w: width of the street (m)
%f_c: transmision frequency (MHz)

    Dh_mobile = h_roof - h_MS;
    if(Dh_mobile > 0)
        if((angle >= 0)&&(angle < 35))
            L_ori = -10 + 0.354*angle;
        elseif((angle >= 35)&&(angle < 55))
            L_ori = 2.5 + 0.075*(angle - 35);
        else
            L_ori = 4.0 - 0.144*(angle - 55);
        end
        L_rts = L_ori - 8.2 - 10*log(w) + 10*log(f_c) + 20*log(Dh_mobile);
    else
        L_rts = 0;
    end
end

