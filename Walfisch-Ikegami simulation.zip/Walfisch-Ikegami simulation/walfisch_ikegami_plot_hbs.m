function [HBS_LdB, HBS_L] = walfisch_ikegami_plot_hbs()
%This function simulates the Losses gained when the height of the base
%station takes different values from 4 to 50 meters in both metropolis and 
%small city scenarios. For the purpose of this simulation, 3 different
%frequencies were used, one low, one medium and one high, and also
%2 different distances, one close to 0.02 meters and the other close to 5 
%meters. Fixed parameters:
%Distance between buildings b: 35m, [20,50] m
%angle: 45�, [0,90] �
%Height of mobile station: 2m, [1,3] m
%Height of a roof in a metropolitan scenario h_roof_metro: 21m
%Height of a roof in a small city scenario h_roof_metro: 9m
%OUTPUTS: The output of this function are the Losses of the simulations
%         both in dB and Watts.

    f_c = 1400;%MHz: 800-2000
    h_BS = 25;%m: 4-50
    h_MS = 2;%m: 1-3
    d = 2.51;%km: 0.02-5
    angle= 90;%degrees: 0-90
    b = 35;%m: 20-50
    h_roof_metro = 21;%m
    h_roof_small = 9;%m
    LOS = true;%line of sight->true || No-LOS->false
    City = true;%Metropolis
    if((800 <= f_c) && (f_c <= 2000) && (d >= 0.02)&&(d <= 5) && (h_BS >= 4)&&(h_BS <= 50) && (h_MS >= 1)&&(h_MS <= 3))
        d = [0.3 2];
        fc = [960 1550 1950];
        HBS = [4:2.5:50];
        rows = length(d)*length(fc);
        HBS_LdB = zeros(rows,length(HBS),2);
        h_roofs = [h_roof_metro h_roof_small];
        HBS_L = HBS_LdB;
        for x = [1 2]   %1 is for Metropolis, 2 is for Small city
            for i = 1:length(HBS)
                for j = [1:length(fc)]
                    for k = [1:length(d)]
                        [HBS_LdB((j-1)*length(d)+k,i,x),HBS_L((j-1)*length(d)+k,i,x)] = WalfichIkegami(fc(j), HBS(i), h_MS, d(k), ~LOS, h_roofs(x), b, City, angle);
                    end
                end
            end
            City = ~City;
        end
        figure('Name','Metropolis Base Station Losses');
        AxesH = axes('Ylim', [200, 380], 'YTick', 200:10:380, 'NextPlot', 'add');
        plot(HBS, HBS_LdB(6,:,1), '-+b',HBS, HBS_LdB(4,:,1), '-*b', HBS, HBS_LdB(2,:,1), '-db',...
             HBS, HBS_LdB(5,:,1), '-+r', HBS, HBS_LdB(3,:,1), '-*r', HBS, HBS_LdB(1,:,1), '-dr');

        grid on;
        title_str = sprintf('Fixed parameters:H_{MS}=%dm, H_{roof}=%dm,\\phi=%d\\circ, b=%dm',...
           h_MS,h_roof_metro, angle, b);
        title({'Losses vs Height of Base Station | Metropolis', title_str});
        xlabel('Base Station Height(m)');
        ylabel('Losses(dB)');

        legend('f=1950MHz, d=2km', 'f=1550MHz, d=2km', 'f=960MHz, d=2km',...
               'f=1950MHz, d=0.3km', 'f=1550MHz, d=0.3km', 'f=960MHz, d=0.3km', 'Location', 'southeastoutside');

        figure('Name','Small City Base Station Losses');
        AxesH = axes('Ylim', [160, 340], 'YTick', 160:10:340, 'NextPlot', 'add');
        plot(HBS, HBS_LdB(6,:,2), '-+b', HBS, HBS_LdB(4,:,2), '-*b', HBS, HBS_LdB(2,:,2), '-db',...
             HBS, HBS_LdB(5,:,2), '-+r', HBS, HBS_LdB(3,:,2), '-*r', HBS, HBS_LdB(1,:,2), '-dr');
        grid on;
        title_str = sprintf('Fixed parameters:H_{MS}=%dm,H_{roof}=%dm,\\phi=%d\\circ,b=%dm',...
           h_MS,h_roof_small, angle, b);
        title({'Losses vs Height of Base Station | Small City', title_str});
        xlabel('Base Station Height(m)');
        ylabel('Losses(dB)');

        legend('f=1950MHz, d=2km', 'f=1550MHz, d=2km', 'f=960MHz, d=2km',...
               'f=1950MHz, d=0.3km', 'f=1550MHz, d=0.3km', 'f=960MHz, d=0.3km', 'Location', 'southeastoutside');
    else
      figure;
      plot(1000,1000);
    end
  end   