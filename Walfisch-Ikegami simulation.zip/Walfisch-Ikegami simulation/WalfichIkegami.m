function [LdB, L] = WalfichIkegami(f_c, h_BS, h_MS, d, LOS, h_roof, b, City, angle)
%% This function calculates the losses according to the Walfisch-Ikegami model. 
%Parameters are:
%f_c: frequency (MHz)
%h_BS: heigth of the Base Station (m)
%h_MS: heigth of the Mobile Station (m)
%d: distance between the 2 stations (km)
%LOS: a flag. If true then the LOS equation is used.
%     If false then Non-LOS equation is used
%b: building distance (m) (Used in L_msd)
%h_roof: heigth of roof in which the BS is located (Used in L_msd)
%City: Binary flag. True is for a small city, False is for
%      Metropolis (Used in L_msd)
%angle: The angle between incidences coming from base 
%       station and road. In degrees (Used in L_rts)

    if((800 <= f_c)&&(f_c <= 2000) && (d >= 0.02)&&(d <= 5) && (h_BS >= 4)&&(h_BS <= 50)...
        && (h_MS >= 1)&&(h_MS <= 3) && (angle >=0)&&(angle <= 90) && (b >= 20)&&(b <= 50))      %Checking if the parameters are inside the boundaries
    
      if(LOS == true)  %Using the equation for the line of sight
          LdB = 42.6 + 26*log(d) + 20*log(f_c);
          L = 10^(LdB/10);
      else          %Using the equation for the Non-LOS
          %calculating the free space losses
          L_FS = 32.45 + 20*log(f_c) + 20*log(d);   
          %calculating the losses for the rooftop to street difraction losses
          L_rts = rtslosses(angle, (b/2), h_roof, h_MS, f_c);
          %calculating the multiscreen diffraction loss      
          L_msd = msdlosses(h_BS, h_roof, f_c, d, b, City);
          
          %calculating the losses in dB
          LdB = L_FS + L_rts + L_msd;
          %calculating the losses in Watts
          L = 10^(LdB/10);
          
      end
      
    else   %one of the parameters was out of range
        L = -1;
        LdB = 1000000000000000;
    end
end